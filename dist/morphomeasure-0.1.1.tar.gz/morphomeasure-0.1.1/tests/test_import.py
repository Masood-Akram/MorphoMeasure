def test_import():
    from morphomeasure import LMeasureWrapper
